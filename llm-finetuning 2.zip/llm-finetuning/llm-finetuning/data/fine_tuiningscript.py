from datasets import load_dataset
from transformers import AutoTokenizer, AutoModelForCausalLM, Trainer, TrainingArguments, DataCollatorForLanguageModeling
from peft import LoraConfig, get_peft_model
import torch
import json

# ------------------------------
# Step 1: Load the dataset
# ------------------------------
def load_jsonl(file_path):
    with open(file_path, "r") as f:
        return [json.loads(line) for line in f]

train_data = load_jsonl("data/summarization_train.jsonl")
test_data = load_jsonl("data/summarization_test.jsonl")

# ------------------------------
# Step 2: Tokenizer and formatting
# ------------------------------
model_name = "distilgpt2"
tokenizer = AutoTokenizer.from_pretrained(model_name)
tokenizer.pad_token = tokenizer.eos_token  # GPT2 has no pad token

def tokenize_fn(example):
    prompt = f"{example['instruction']}\n\nArticle:\n{example['input']}\n\nSummary:"
    labels = example["output"]
    inputs = tokenizer(prompt, truncation=True, padding="max_length", max_length=512)
    outputs = tokenizer(labels, truncation=True, padding="max_length", max_length=128)
    inputs["labels"] = outputs["input_ids"]
    return inputs

# Tokenize dataset
from datasets import Dataset
train_dataset = Dataset.from_list(train_data).map(tokenize_fn, batched=False)
test_dataset = Dataset.from_list(test_data).map(tokenize_fn, batched=False)

# ------------------------------
# Step 3: Load base model
# ------------------------------
base_model = AutoModelForCausalLM.from_pretrained(model_name)

# ------------------------------
# Step 4: Apply LoRA for efficient fine-tuning
# ------------------------------
lora_config = LoraConfig(
    r=8,                 # rank
    lora_alpha=32,       # scaling factor
    target_modules=["c_attn"],  # which layers to apply LoRA on
    lora_dropout=0.05,
    bias="none",
    task_type="CAUSAL_LM"
)
model = get_peft_model(base_model, lora_config)
model.print_trainable_parameters()

# ------------------------------
# Step 5: Training setup
# ------------------------------
training_args = TrainingArguments(
    output_dir="./results",
    num_train_epochs=2,
    per_device_train_batch_size=2,
    per_device_eval_batch_size=2,
    warmup_steps=10,
    weight_decay=0.01,
    logging_dir="./logs",
    logging_steps=50,
    save_total_limit=1,
    fp16=torch.cuda.is_available(),
)


data_collator = DataCollatorForLanguageModeling(tokenizer=tokenizer, mlm=False)

trainer = Trainer(
    model=model,
    args=training_args,
    data_collator=data_collator,
    train_dataset=train_dataset,
    eval_dataset=test_dataset,
)

# ------------------------------
# Step 6: Train!
# ------------------------------
trainer.train()
trainer.save_model("./fine_tuned_distilgpt2_lora")

print("✅ Fine-tuning complete! Model saved to ./fine_tuned_distilgpt2_lora")
