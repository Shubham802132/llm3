from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel
from datasets import load_dataset
import evaluate
import torch

# 1️⃣ Base model and device setup
base_model = "distilgpt2"
device = "cuda" if torch.cuda.is_available() else "cpu"

# 2️⃣ Load base model and LoRA adapter
model = AutoModelForCausalLM.from_pretrained(base_model)
tokenizer = AutoTokenizer.from_pretrained(base_model)
if tokenizer.pad_token is None:
    tokenizer.add_special_tokens({'pad_token': '[PAD]'})
    model.resize_token_embeddings(len(tokenizer))
model = PeftModel.from_pretrained(model, "./results/checkpoint-2000")
model.to(device)
model.eval()

# 3️⃣ Load dataset (small portion for evaluation)
dataset = load_dataset("cnn_dailymail", "3.0.0", split="test[:1%]")

# 4️⃣ Load ROUGE metric
rouge = evaluate.load("rouge")

# 5️⃣ Generate summaries
def generate_summary(batch):
    inputs = tokenizer(batch["article"], max_length=512, truncation=True, return_tensors="pt", padding="max_length").to(model.device)
    with torch.no_grad():
        outputs = model.generate(
            input_ids=inputs.input_ids,
            attention_mask=inputs.attention_mask,
            max_new_tokens=150,       # ✅ use max_new_tokens instead of max_length
            num_beams=4,
            early_stopping=True,
            pad_token_id=tokenizer.eos_token_id
        )
    batch["predicted_summary"] = tokenizer.decode(outputs[0], skip_special_tokens=True)
    return batch


# Apply generation
results = dataset.map(generate_summary, batched=False)

# 6️⃣ Compute ROUGE scores
rouge_output = rouge.compute(
    predictions=results["predicted_summary"],
    references=results["highlights"],
    use_stemmer=True
)

# 7️⃣ Print results
print("✅ Evaluation Results:")
for key in rouge_output:
    print(f"{key}: {rouge_output[key]:.4f}")
