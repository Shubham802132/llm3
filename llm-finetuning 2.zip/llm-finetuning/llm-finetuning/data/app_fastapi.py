from fastapi import FastAPI
from pydantic import BaseModel
from transformers import AutoTokenizer, AutoModelForCausalLM
from peft import PeftModel
import torch

app = FastAPI(title="Summarization API")

# -------------------------------
# Load base model + tokenizer
# -------------------------------
base_model = "distilgpt2"

tokenizer = AutoTokenizer.from_pretrained(base_model)

# Make sure pad token exists
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token

model = AutoModelForCausalLM.from_pretrained(base_model)

# Load LoRA fine-tuned weights
model = PeftModel.from_pretrained(model, "./results/checkpoint-2000")

device = "cuda" if torch.cuda.is_available() else "cpu"
model.to(device)
model.eval()


# -------------------------------
# Request Body
# -------------------------------
class InputText(BaseModel):
    article: str


# -------------------------------
# Endpoints
# -------------------------------
@app.get("/")
def home():
    return {"message": "Summarization API is running!"}


@app.post("/summarize")
def summarize(input: InputText):
    # Tokenize
    inputs = tokenizer(
        input.article,
        return_tensors="pt",
        truncation=True,
        padding=True
    ).to(device)

    # Generate summary
    with torch.no_grad():
        output_ids = model.generate(
            **inputs,
            max_new_tokens=150,
            num_beams=4,
            pad_token_id=tokenizer.eos_token_id
        )

    summary = tokenizer.decode(output_ids[0], skip_special_tokens=True)
    return {"summary": summary}
