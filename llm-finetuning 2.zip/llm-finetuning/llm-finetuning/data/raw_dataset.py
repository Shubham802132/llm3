from datasets import load_dataset
import json
import random

# Load CNN/DailyMail dataset
dataset = load_dataset("cnn_dailymail", "3.0.0")

# Convert it into instruction-style format
def format_sample(example):
    return {
        "instruction": "Summarize the following news article:",
        "input": example["article"],
        "output": example["highlights"]
    }

# Apply formatting
train_data = dataset["train"].map(format_sample)
test_data = dataset["test"].map(format_sample)

# Take a smaller subset (for 1k–5k samples)
small_train = train_data.shuffle(seed=42).select(range(2000))
small_test = test_data.shuffle(seed=42).select(range(500))

# Save to JSONL (for fine-tuning)
with open("summarization_train.jsonl", "w") as f:
    for example in small_train:
        f.write(json.dumps(example) + "\n")

with open("summarization_test.jsonl", "w") as f:
    for example in small_test:
        f.write(json.dumps(example) + "\n")

print("✅ Dataset prepared: summarization_train.jsonl and summarization_test.jsonl")

